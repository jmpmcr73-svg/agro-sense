# AGROSENSe Pro 🌿

Sistema de Monitoreo Ambiental Móvil para Invernaderos

## Stack
- HTML + Vanilla JS (sin dependencias)
- Supabase (base de datos)
- Vercel (hosting)

## Deploy
Conectar repo en vercel.com → deploy automático en cada push.
